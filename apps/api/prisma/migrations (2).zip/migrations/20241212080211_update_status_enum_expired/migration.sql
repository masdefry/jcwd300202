-- AlterEnum
ALTER TYPE "Status" ADD VALUE 'EXPIRED';
