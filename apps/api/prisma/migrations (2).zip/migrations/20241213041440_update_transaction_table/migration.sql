-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "adult" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "children" INTEGER NOT NULL DEFAULT 0;
