-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "nights" INTEGER NOT NULL DEFAULT 1;
