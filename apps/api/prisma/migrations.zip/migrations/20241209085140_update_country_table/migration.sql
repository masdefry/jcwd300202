/*
  Warnings:

  - You are about to drop the column `profilePictureUrl` on the `profile` table. All the data in the column will be lost.
  - Added the required column `description` to the `countries` table without a default value. This is not possible if the table is not empty.
  - Added the required column `directory` to the `countries` table without a default value. This is not possible if the table is not empty.
  - Added the required column `filename` to the `countries` table without a default value. This is not possible if the table is not empty.
  - Added the required column `description` to the `property_room_types` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "countries" ADD COLUMN     "description" TEXT NOT NULL,
ADD COLUMN     "directory" TEXT NOT NULL,
ADD COLUMN     "filename" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "profile" DROP COLUMN "profilePictureUrl",
ADD COLUMN     "directory" TEXT,
ADD COLUMN     "filename" TEXT,
ALTER COLUMN "username" SET DEFAULT 'Roomify''s friend';

-- AlterTable
ALTER TABLE "property_room_types" ADD COLUMN     "description" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "tenants" ADD COLUMN     "address" TEXT,
ADD COLUMN     "directory" TEXT,
ADD COLUMN     "filename" TEXT,
ADD COLUMN     "phoneNumber" TEXT,
ADD COLUMN     "pic" TEXT DEFAULT 'Roomify''s tenant';
