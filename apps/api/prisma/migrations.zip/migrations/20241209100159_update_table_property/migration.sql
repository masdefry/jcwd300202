/*
  Warnings:

  - You are about to drop the column `propertyTypeId` on the `property` table. All the data in the column will be lost.
  - Added the required column `propertyType` to the `property` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "property" DROP CONSTRAINT "property_propertyTypeId_fkey";

-- AlterTable
ALTER TABLE "property" DROP COLUMN "propertyTypeId",
ADD COLUMN     "propertyType" TEXT NOT NULL;
